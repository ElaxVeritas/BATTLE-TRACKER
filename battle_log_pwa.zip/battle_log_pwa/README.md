# BATTLE LOG // PWA DEPLOYMENT GUIDE

You have a working Progressive Web App. Now you need to put it on the internet so you and your friends can install it.

The fastest free option: **GitHub Pages** or **Netlify Drop**. Both take ~5 minutes.

---

## OPTION A — NETLIFY DROP (easiest, ~2 minutes)

1. Go to https://app.netlify.com/drop
2. Sign up (free) or log in
3. Drag this entire `battle_log_pwa` folder onto the page
4. Wait ~10 seconds. Netlify gives you a URL like `https://random-name-12345.netlify.app`
5. Open that URL on your phone in Chrome (Android) or Safari (iOS)
6. Tap menu → "Add to Home Screen" / "Install App"
7. Done. Real app icon, fullscreen, works offline.

To share with friends: send them the URL. They install it the same way.

To customize the URL: in Netlify dashboard → Site settings → Change site name to something like `niko-battle-log`.

---

## OPTION B — GITHUB PAGES (free forever, slightly more setup)

1. Go to https://github.com and create an account (free)
2. Click "+" → "New repository" — name it `battle-log` — make it Public
3. Click "uploading an existing file"
4. Drag all 7 files from `battle_log_pwa` folder
5. Click "Commit changes"
6. Go to Settings → Pages
7. Under "Branch", select `main` → `/ (root)` → Save
8. Wait 1–2 minutes
9. Your URL: `https://YOUR-USERNAME.github.io/battle-log/`

---

## INSTALLING THE APP

**On Android (Chrome):**
- Open the URL
- Tap the 3-dot menu
- Tap "Install app" or "Add to Home Screen"
- The app appears on your home screen with the BL icon

**On iPhone (Safari):**
- Open the URL
- Tap the Share button (square with up arrow)
- Tap "Add to Home Screen"
- The app appears on your home screen with the BL icon

After install, opening the icon launches it fullscreen — no browser bar, looks like a real app.

---

## WHAT THE FILES DO

```
index.html       — the app itself
manifest.json    — tells the phone "this is an installable app"
sw.js            — service worker, makes it work offline
icon-192.png     — small icon (Android)
icon-512.png     — large icon (Android)
icon-maskable.png — Android adaptive icon
favicon.png      — browser tab icon
```

All 7 files must be in the same folder for it to work.

---

## DATA STORAGE

Each person's workout data is saved on **their own phone**. There's no shared database. You can't see each other's logs. If your friend reinstalls, they lose their data.

If you want shared data (you could see your friends' workouts, leaderboards, etc.) that's a different build — needs a backend. Tell me if you want that later.

---

## UPDATING THE APP

When I send you a new version of `index.html` (bug fix, new feature):
- Replace the file in your hosting (drag-drop on Netlify, commit on GitHub)
- The app auto-updates next time anyone opens it (the service worker handles this)
- Saved workout data is preserved across updates
